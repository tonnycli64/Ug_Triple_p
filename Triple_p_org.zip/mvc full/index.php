<?php
$built_in = $_;


echo "<pre>";
 print_r($built_in);
echo "</pre>";


