<?php
/**
 * User modal
 */

class User
{
  public $errors = [];
  protected $table = 'users';

  public function validate($data)
  {
    $this->errors = [];

    if(empty($data['full_name']))
    {
      $this->errors['full_name'] = 'your full name are required';
    }

    if(empty($this->errors))
    {
      return true;
    }

    return false;
  }

}