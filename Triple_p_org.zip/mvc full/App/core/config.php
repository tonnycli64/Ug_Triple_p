<?php
/***
 * app info
 */
define('APP_NAME', 'UDEMY APP');
define('APP_DESC', 'UDEMY APP TUTORIALS');

/***
 * database confic
 */

if($_SERVER['SERVER_NAME'] == 'localhost'){
  //confic for local server
  define('DBHOST', 'localhost');
  define('DBNAME', 'udemy_db');
  define('DBUSER', 'root');
  define('DBPASS', 'Choosenby8');
  define('DBDRIVER', 'mysql');

  //root path eg localhost
  define('ROOT', 'http://localhost/mvc%20full/Public');

}else{
    //confic for live server
    define('DBHOST', 'localhost');
    define('DBNAME', 'udemy_db');
    define('DBUSER', 'root');
    define('DBPASS', 'Choosenby8');
    define('DBDRIVER', 'mysql');

     //root path eg https://ww.yourdomain.com
 define('ROOT', 'https://');
}