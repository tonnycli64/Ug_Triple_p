<?php

echo 'silent is golden';