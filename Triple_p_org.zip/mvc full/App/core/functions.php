<?php

function show($staff) {
  echo '<pre>';
  print_r($staff);
  echo '</pre>';
}