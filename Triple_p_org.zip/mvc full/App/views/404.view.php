<?php $this->view('includes/header',$data) ?>
<?php $this->view('includes/nav',$data) ?>

<div class="container-fluid p-4 text-center">
 <h1>page not found error: 404</h1>
</div>
<?php $this->view('includes/footer',$data) ?>