<?php

class Home extends Controller
{
  public function index()
  {
    $db = new Database();
   $res = $db->create_tables();
    $data['title'] = 'Home';

    $this->view('home', $data);
  }

}